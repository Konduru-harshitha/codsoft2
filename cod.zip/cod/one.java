package codsoft;
import java.util.*;
import java.util.Random; 
public class Number_Game {
  public static void main(String[] args) {
	  Scanner sc=new Scanner(System.in);
	  int count=0;
	  Random randomnum=new Random();
	  int The_num=randomnum.nextInt(100);
	  System.out.println("your Guess :");
	  for(int i=1;i<=3;i++) {
	  int num=sc.nextInt();
	  if(The_num==num) {
		  System.out.println("your guess is right");
		  count++;
		  break;
	  }
	  else if(i!=3) {
		  System.out.println("try again...better luck");
		  
	  }
	 }
	  if(count==0) {
	  System.out.println("you lost");
	  System.out.println("the number is : "+ The_num);
	  }
}
}